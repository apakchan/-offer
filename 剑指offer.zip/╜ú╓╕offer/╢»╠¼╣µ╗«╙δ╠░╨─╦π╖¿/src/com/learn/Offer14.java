package com.learn;

public class Offer14 {

    static int maxProductAfterCutting_DP(int length){
        if (length < 2) return 0;
        if (length == 2) return 1;
        if (length == 3) return 2;

        int[] f = new int[length + 1];
        f[0] = 0;
        f[1] = 1;
        f[2] = 2;
        f[3] = 3;

        int max = -1;
        for (int i = 4; i <= length; i ++) {
            max = -1;
            for(int j = 1; j <= i / 2; j ++){
                max = Integer.max(max, f[j] * f[i - j]);
            }
            f[i] = max;
        }

        return max;
    }

    static int maxProductAfterCutting_Greedy(int length){
        if (length < 2) return 0;
        if (length == 2) return 1;
        if (length == 3) return 2;

        //尽可能多的剪去商都为3的绳子段
        int timeOf3 = length / 3;

        //当绳子最后剩下的长度为 4时，不能再减去长度为3的绳子段
        //因为 2 x 2 > 1 x 3
        if(length - timeOf3 * 3 == 1){
            timeOf3 --;
        }

        //剪成长度为 2的段数
        int timeOf2 = (length - timeOf3 * 3) / 2;

        return (int)Math.pow(3, timeOf3) * (int)Math.pow(2, timeOf2);
    }


    public static void main(String[] args) {

        System.out.println(maxProductAfterCutting_Greedy(5));
    }
}
