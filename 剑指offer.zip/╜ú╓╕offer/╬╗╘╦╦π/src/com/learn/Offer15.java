package com.learn;

public class Offer15 {

    static int numberOf1(int n){
        int cnt = 0;
        while(n != 0){
            if((n & 1) == 1) cnt ++;
            n = n >> 1;
        }
        return cnt;
    }

    static int numberOf1_p(int n){
        int cnt = 0;
        int flag = 1;
        while(flag != 0){

            if((n & flag) != 0) cnt ++;

            flag = flag << 1;
        }
        return cnt;
    }

    static int numberOf_1_best(int n){
        int cnt = 0;
        while(n != 0){
            cnt ++;
            n = (n - 1) & n;
        }
        return cnt;
    }


    public static void main(String[] args) {
        System.out.println(numberOf_1_best(3));

    }
}
