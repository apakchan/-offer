package com.learn;

public class ListNodeOperation {

    //打印链表
    static void printListNode(MyListNode pHead){
        if (pHead == null){
            System.out.println(pHead);
        }

        MyListNode p = pHead;

        while (p != null){
            System.out.println(p.value);
            p = p.next;
        }

    }

    //删除链表中值等于value的元素
    static void remove(MyListNode pHead, int value){
        if(pHead == null) return;

        MyListNode dummy = new MyListNode(-1, pHead);

        MyListNode p = pHead;
        MyListNode q = dummy;

        while (p != null){
            if(p.value == value){
                q.next = p.next;
            }
            q = q.next;
            p = p.next;
        }

        dummy = null;
    }

    //向链表尾部添加一个元素
    static void addToTail(MyListNode pHead, int value){
        if(pHead == null) return;

        MyListNode p = pHead;

        while (p.next != null){
            p = p.next;
        }

        p.next = new MyListNode(value, null);
    }

    public static void main(String[] args) {
        MyListNode node = new MyListNode(1, new MyListNode(2, new MyListNode(3, null)));
        addToTail(node, 4);
        printListNode(node);
        remove(node, 4);
        printListNode(node);
    }
}
