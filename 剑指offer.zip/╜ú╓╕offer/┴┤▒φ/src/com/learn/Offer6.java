package com.learn;

public class Offer6 {

    static void printListReverse(MyListNode pHead){
        if(pHead == null) return;

        printListReverse(pHead.next);

        System.out.println(pHead.value);
    }

    public static void main(String[] args) {
        MyListNode node = new MyListNode(1, new MyListNode(2, new MyListNode(3, null)));
        printListReverse(node);
    }
}
