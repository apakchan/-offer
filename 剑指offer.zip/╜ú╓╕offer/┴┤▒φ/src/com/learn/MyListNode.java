package com.learn;

public class MyListNode {
    int value;
    MyListNode next;

    public MyListNode() {}

    public MyListNode(int value, MyListNode next) {
        this.value = value;
        this.next = next;
    }
}
