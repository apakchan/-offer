package com.learn;

import java.util.Stack;

public class Offer9 {
    private static Stack<Integer> stack1 = new Stack<>();
    private static Stack<Integer> stack2 = new Stack<>();

    public static int deleteHead(){
        if(stack2.size() == 0){
            if(stack1.size() == 0) return -1;
            while(stack1.size() > 0){
                int data = stack1.peek();
                stack1.pop();
                stack2.push(data);
            }
        }

        return stack2.pop();
    }

    public static void appendTail(int integer){
        stack1.push(integer);
    }

    public static void main(String[] args) {
        appendTail(11);
        System.out.println(deleteHead());
        appendTail(1);
        appendTail(17);
        System.out.println(deleteHead());
        System.out.println(deleteHead());
        appendTail(19);
        appendTail(20);
        appendTail(13);
        System.out.println(deleteHead());
        System.out.println(deleteHead());
        System.out.println(deleteHead());
        appendTail(12);
        appendTail(3);
        System.out.println(deleteHead());
        System.out.println(deleteHead());
        System.out.println(deleteHead());
        appendTail(10);
        appendTail(19);
        System.out.println(deleteHead());
    }
}
