package com.learn;

import java.util.Arrays;

public class Offer12 {
    static boolean hasPath(char[] matrix, int rows, int cols, String str){
        if(matrix == null || rows <= 0 || cols <= 0 || str == null) return false;

        boolean[] st = new boolean[rows * cols];
        Arrays.fill(st, false);

        Integer pathLength = 0;
        for(int row = 0; row < rows; row ++)
            for (int col = 0; col < cols; col++) {
                if(hasPathCore(matrix, rows, cols, row, col,
                        str, pathLength, st))
                    return true;
            }

        st = null;

        return false;
    }

    static boolean hasPathCore(char[] matrix, int rows, int cols, int row, int col, String str, Integer pathLength, boolean[] st){

        if(str.length() <= pathLength) return true;

        boolean hasPath = false;

        if(row >=0 && row < rows && col >= 0 && col < cols
                && matrix[row * cols + col] == str.charAt(pathLength)
                && !st[row * cols + col]) {
            pathLength = pathLength + 1;

            st[row * cols + col] = true;

            hasPath = hasPathCore(matrix, rows, cols, row, col - 1, str, pathLength, st)
                    || hasPathCore(matrix, rows, cols, row - 1, col, str, pathLength, st)
                    || hasPathCore(matrix, rows, cols, row + 1, col, str, pathLength, st)
                    || hasPathCore(matrix, rows, cols, row, col + 1, str, pathLength, st);

            if(!hasPath){  //回溯，需要返回到之前的字符，重新定位
                pathLength = pathLength - 1;
                st[row * rows + col] = false;
            }
        }
        return hasPath;
    }

    public static void main(String[] args) {
        char[] matrx = new char[]{
          'a', 'b', 't', 'g',
          'c', 'f', 'c', 's',
          'j', 'd', 'e', 'h'
        };
        System.out.println(hasPath(matrx, 3, 4, "acje"));
    }
}
