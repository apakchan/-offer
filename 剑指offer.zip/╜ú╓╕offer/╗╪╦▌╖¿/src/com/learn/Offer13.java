package com.learn;

import java.util.Arrays;

public class Offer13 {

    static int movingCount(int k, int rows, int cols){
        if(k < 0 || rows <= 0 || cols <= 0) return 0;

        boolean[] st = new boolean[rows * cols];
        Arrays.fill(st, false);

        int count = movingCountCore(k, rows, cols, 0, 0, st);

        st = null;

        return count;
    }

    static int movingCountCore(int k, int rows, int cols, int row, int col, boolean[] st){
        int count = 0;
        if(check(k, rows, cols, row, col, st)){
            st[row * cols + col] = true;
            System.out.println("(" + row + ", " + col + ")" + "-> " + (getDigitSum(row) + getDigitSum(col)));
            count = 1 + movingCountCore(k, rows, cols, row - 1, col, st)
                    + movingCountCore(k, rows, cols, row, col - 1, st)
                    + movingCountCore(k, rows, cols, row + 1, col, st)
                    + movingCountCore(k, rows, cols, row, col + 1, st);
        }
        return  count;
    }

    static boolean check(int k, int rows, int cols, int row, int col, boolean[] st){
        if(row >= 0 && row < rows && col >= 0 && col < cols && !st[row * cols + col]
                && getDigitSum(row) + getDigitSum(col) <= k)
            return true;
        return  false;
    }

    static int getDigitSum(int num){
        int res = 0;
        while(num > 0){
            res += num % 10;
            num /= 10;
        }
        return  res;
    }

    public static void main(String[] args) {
        System.out.println(movingCount(10, 100, 100));
    }
}
