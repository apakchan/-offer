package com.learn;

public class Offer42 {

    static final int INF = 0x3f3f3f3f;

    static Integer findGreatestSumOfSubArray(int[] data, int length){
        if(data == null || length <= 0) {
            return null;
        }

        int nCurSum = 0;
        int nGreatestSum = -INF;
        for (int i = 0; i < length; i++) {
            if(nCurSum <= 0)
                nCurSum = data[i];
            else
                nCurSum += data[i];

            if(nCurSum > nGreatestSum)
                nGreatestSum = nCurSum;
        }

        return nGreatestSum;
    }

    public static void main(String[] args) {
        int[] data = {1, -2, 3, 10, -4, 7, 2, -5};
        Integer res = findGreatestSumOfSubArray(data, data.length);
        System.out.println(res);
    }
}
