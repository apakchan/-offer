package com.learn;

import java.util.Arrays;

public class Offer50_2 {
    static class CharStatistics{
        private int[] hashTable = new int[256];
        private int index = 0;

        public CharStatistics(){
            Arrays.fill(hashTable, -1);
        }

        public void insertCharacter(char c){
            if(hashTable[c] == -1){
                hashTable[c] = index;
            } else if (hashTable[c] >= 0){
                hashTable[c] = -2;
            }

            index ++;
        }

        public Character firstAppearingOnce() {
            Character c = null;

            int minIndex = Integer.MAX_VALUE;

            for (int i = 0; i < 256; i++) {
                if (hashTable[i] >= 0 && hashTable[i] < minIndex){
                    c = (char) i;
                    minIndex = hashTable[i];
                }
            }

            return c;
        }
    }

    public static void main(String[] args) {
        CharStatistics obj = new CharStatistics();
        obj.insertCharacter('g');
        obj.insertCharacter('o');
        System.out.println(obj.firstAppearingOnce());
        obj.insertCharacter('o');
        obj.insertCharacter('g');
        obj.insertCharacter('l');
        obj.insertCharacter('e');
        System.out.println(obj.firstAppearingOnce());
    }
}
