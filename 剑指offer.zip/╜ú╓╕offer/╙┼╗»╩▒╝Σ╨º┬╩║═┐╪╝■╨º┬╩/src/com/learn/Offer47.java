package com.learn;

public class Offer47 {
    static int getMaxValue(int[][] gift, int rows, int cols){
        if(gift == null || rows <= 0 || cols <= 0)
            return 0;

        int[][] f = new int[rows][cols];
        for (int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {

                int left = 0;
                int up = 0;

                if (i - 1 >= 0)
                    left = f[i - 1][j];

                if(j - 1 >= 0)
                    up = f[i][j - 1];

                f[i][j] = Integer.max(left, up) + gift[i][j];
            }
        }
        return f[rows - 1][cols - 1];
    }

    public static void main(String[] args) {
        int[][] gift = {
                {1, 10, 3, 8},
                {12, 2, 9, 6},
                {5, 7, 4, 11},
                {3, 7, 16, 5}
        };
        System.out.println(getMaxValue(gift, gift.length, gift[0].length));
    }
}
