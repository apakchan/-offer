package com.learn;

import java.sql.PseudoColumnUsage;
import java.util.List;
import java.util.Stack;

public class Offer52 {
    static class ListNode{
        int value;
        ListNode next;

        public ListNode() {
        }

        public ListNode(int value, ListNode next) {
            this.value = value;
            this.next = next;
        }
    }

    static ListNode findFirstCommonNode(ListNode pHead1, ListNode pHead2){
        if (pHead1 == null || pHead2 == null) return null;
        ListNode p1 = pHead1;
        ListNode p2 = pHead2;
        Stack<ListNode> stack1 = new Stack<>();
        Stack<ListNode> stack2 = new Stack<>();

        while (p1 != null){
            stack1.push(p1);
            p1 = p1.next;
        }
        while (p2 != null){
            stack2.push(p2);
            p2 = p2.next;
        }

        ListNode node1 = stack1.peek();
        ListNode node2 = stack2.peek();
        while (node1 == node2){
            node1 = stack1.pop();
            node2 = stack2.pop();
        }

        return node1.next;
    }

    static ListNode findFirstCommonNode_2(ListNode pHead1, ListNode pHead2){
        if (pHead1 == null || pHead2 == null) return null;
        ListNode p1 = pHead1;
        ListNode p2 = pHead2;

        int countOf1 = 0;
        int countOf2 = 0;

        while (p1 != null){
            countOf1 ++;
            p1 = p1.next;
        }
        while (p2 != null){
            countOf2 ++;
            p2 = p2.next;
        }

        ListNode pShort = pHead1;
        ListNode pLong = pHead2;

        if (countOf1 > countOf2){
            pLong = pHead1;
            pShort = pHead2;
        }

        for (int i = 0; i < Math.abs(countOf1 - countOf2); i++) {
            pLong = pLong.next;
        }

        while (pLong != null && pShort != null && pLong != pShort){
            pLong = pLong.next;
            pShort = pShort.next;
        }

        return pLong;
    }

    public static void main(String[] args) {
        ListNode common = new ListNode(6, new ListNode(7, null));
        ListNode head1 = new ListNode(1, new ListNode(2, new ListNode(3, common)));
        ListNode head2 = new ListNode(4, new ListNode(5, common));
        System.out.println(findFirstCommonNode_2(head1, head2).value);
    }
}
