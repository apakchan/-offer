package com.learn;

import java.util.Arrays;
import java.util.Comparator;

public class Offer45 {
    static void printMinNumber(Integer[] numbers, int length){
        if (numbers == null || length <= 0) return;

        Arrays.sort(numbers, (o1, o2) -> {
            String s1 = String.valueOf(o1) + o2;
            String s2 = String.valueOf(o2) + o1;
            return s1.compareTo(s2);
        });

        for (Integer number : numbers) {
            System.out.print(number);
        }
    }

    public static void main(String[] args) {
        Integer[] a = {1, 2313, 12432,234, 9123};
        printMinNumber(a, a.length);
    }
}
