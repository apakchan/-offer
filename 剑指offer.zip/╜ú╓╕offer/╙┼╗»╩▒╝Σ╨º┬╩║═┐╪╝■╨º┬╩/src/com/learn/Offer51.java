package com.learn;

import java.util.Arrays;

public class Offer51 {
    static int inversePairs(int[] data, int length){
        if(data == null || length <= 0) return 0;

        int[] copy = Arrays.copyOf(data, length);

        int count = inversePairsCore(data, copy, 0, length - 1);

        return count;
    }

    private static int inversePairsCore(int[] data, int[] copy, int start, int end) {
        if (start == end){
            copy[start] = data[start];
            return 0;
        }

        int length = (end - start) / 2;

        int left = inversePairsCore(copy, data, start, start + length);
        int right = inversePairsCore(copy, data, start + length + 1, end);

        int i = start + length;
        int j = end;
        int indexOfCopy = end;
        int count = 0;
        while (i >= start && j >= start + length + 1){
            if (data[i] > data[j]){
                copy[indexOfCopy --] = data[i --];
                count += j - start - length;
            } else {
                copy[indexOfCopy --] = data[j --];
            }
        }

        //把剩下的元素添加到 copy数组中
        for (; i >= start ; i --) {
            copy[indexOfCopy --] = data[i];
        }

        for (; j >= start + length + 1; j --){
            copy[indexOfCopy --] = data[j];
        }

        return left + right + count;
    }

    public static void main(String[] args) {
        int[] data = {7, 5, 6, 4};
        System.out.println(inversePairs(data, data.length));
    }
}
