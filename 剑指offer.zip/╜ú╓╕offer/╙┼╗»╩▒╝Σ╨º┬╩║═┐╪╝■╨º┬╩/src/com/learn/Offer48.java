package com.learn;

import java.util.Arrays;

public class Offer48 {
    static int longestSubStringWithoutDuplication(String s){
        int curLength = 0;
        int maxLength = 0;
        if(s == null)
            return 0;

        int[] position = new int[26];
        Arrays.fill(position, -1);

        for (int i = 0; i < s.length(); i++) {
            int prevIndex = position[s.charAt(i) - 'a'];
            //如果第 i 个字符之前没出现过，或者出现在 f(i - 1)之前
            //f(i) = f(i - 1) + 1
            if(prevIndex < 0 || i - prevIndex > curLength)
                curLength ++;
            else {
                //否则首先更新 maxLength
                if (curLength > maxLength)
                    maxLength = curLength;
                //f(i) = d;
                curLength = i - prevIndex;
            }
            //更新第 i 个字符上次出现的位置
            position[s.charAt(i) - 'a'] = i;
        }
        if (curLength > maxLength)
            maxLength = curLength;
        return maxLength;
    }

    public static void main(String[] args) {
        System.out.println(longestSubStringWithoutDuplication("arabcacfr"));
    }
}
