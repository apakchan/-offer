package com.learn;

import java.util.HashSet;
import java.util.Set;

public class Offer46 {

    private static Set<String> set = new HashSet<>();

    static int getNumber(int n){
        String s = n + "";

        return getNumber_2(s);
    }

    private static int getNumber(String s) {
        if (s == null || s.length() == 0 || set.contains(s))
            return 0;

        set.add(s);

        int num = 1;

        num += getNumber(s.substring(1));

        if (s.length() >= 2) {
            int number;
            number = Integer.parseInt(s.substring(0, 2));
            if (number >= 10 && number <= 25)
                num += getNumber(s.substring(2));
        }
        return num;
    }

    private static int getNumber_2(String s){
        int length = s.length();
        int[] counts = new int[length];
        int count;

        for(int i = length - 1; i >= 0; i --){
            count = 0;
            if (i < length - 1)
                count = counts[i + 1];
            else  count = 1;

            if(i < length - 1){
                int digit1 = s.charAt(i) - '0';
                int digit2 = s.charAt(i + 1) - '0';
                int converted = digit1 * 10 + digit2;
                if (converted >= 10 && converted <= 25){
                    if (i < length - 2)
                        count += counts[i + 2];
                    else
                        count += 1;
                }
            }
            counts[i] = count;
        }

        count = counts[0];

        return count;
    }

    public static void main(String[] args) {
        System.out.println(getNumber(12258));
    }


}
