package com.learn;

public class Offer44 {
    static int digitAtIndex(int index){
        if (index < 0) return -1;

        int digits = 1;
        while (true){
            int numbers = countOfDigits(digits);
            if (index < numbers * digits)
                return digitAtIndex(index, digits);
            index -= digits * numbers;
            digits ++;
        }
    }

    //找到明确的数字，返回正确的位数
    private static int digitAtIndex(int index, int digits) {
        int number = beginNumbers(digits) + index / digits;
        int indexFromRight = digits - index % digits;
        for (int i = 1; i < indexFromRight; i++) {
            number /= 10;
        }
        return number % 10;
    }

    //开始的数字，比如两位数就是 10，三位数就是 100
    private static int beginNumbers(int digits){
        if (digits == 1)
            return 0;

        return (int) Math.pow(10, digits - 1);
    }

    //返回每位数有多少个数字，例如三位数是100-999，则一共有 900位
    private static int countOfDigits(int digits) {
        if (digits == 1)
            return 10;

        int count = (int) Math.pow(10, digits - 1);
        return 9 * count;
    }

    public static void main(String[] args) {
        System.out.println(digitAtIndex(1001));
    }
}
