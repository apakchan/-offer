package com.learn;

import java.util.Comparator;
import java.util.TreeSet;

public class Offer40 {
    static int partition(int[] arr, int length, int start, int end) throws Exception {
        if (arr == null || length <=0 || start < 0 || end >= length)
            throw new Exception("输入错误！");

        int index = (end + start) >> 1;
        int temp = arr[index];
        arr[index] = arr[end];
        arr[end] = temp;

        int small = start - 1;
        for (int i = start; i < end; i++) {
            if(arr[i] < arr[end]){
                small ++;
                if (small != i){
                    int t = arr[i];
                    arr[i] = arr[small];
                    arr[small] = t;
                }
            }
        }

        small ++;
        temp = arr[small];
        arr[small] = arr[end];
        arr[end] = temp;

        return small;
    }

    static void getLeastNumbers(int[] input, int length, int[] output, int k) throws Exception {
        if (input == null || output == null || length <= 0 || k <= 0 || k > length)
            return;

        int start = 0;
        int end = length - 1;
        int index = partition(input, length, start, end);

        while (index != k - 1){
            if (index > k - 1){
                end = index - 1;
                index = partition(input, length, start, end);
            } else {
                start = index + 1;
                index = partition(input, length, start, end);
            }
        }

        for (int i = 0; i < k; i++) {
           output[i] = input[i];
        }
    }

    static void getLeastNumbers(int[] input, int length, TreeSet<Integer> output, int k){
        if (input == null || output == null || length <= 0 || k <= 0 || k > length)
            return;

        for (int i = 0; i < length; i++) {
            if (output.size() < k) {
                output.add(input[i]);
            } else {
                int max = output.first();  //最大堆中的最大元素
                if (max <= input[i])
                    continue;  //如果最大值小于当前值则当前值抛弃
                else {
                    //最大值小于当前值则当前值插入
                    output.remove(max);
                    output.add(input[i]);
                }
            }
        }

    }

    public static void main(String[] args) throws Exception {
        TreeSet<Integer> ts = new TreeSet<>(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return -o1.compareTo(o2);
            }
        });

        int[] input = {4,5,1,6,2,7,3,8};

        getLeastNumbers(input, input.length, ts, 4);
        for (Integer t : ts) {
            System.out.print(t + " ");
        }
    }
}
