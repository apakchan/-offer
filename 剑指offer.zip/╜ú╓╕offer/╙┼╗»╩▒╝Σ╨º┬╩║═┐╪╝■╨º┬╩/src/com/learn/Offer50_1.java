package com.learn;

import java.util.Arrays;

public class Offer50_1 {

    static Character firstNotRepeatingChar(String s){
        if (s == null || s.length() == 0)
            return null;

        int[] hashTable = new int[256];
        Arrays.fill(hashTable, 0);

        for(int i = 0; i < s.length(); i ++){
            hashTable[s.charAt(i)] ++;
        }

        Character c = null;

        for (int i = 0; i < s.length(); i ++){
            if (hashTable[s.charAt(i)] == 1) {
                c = s.charAt(i);
                break;
            }
        }

        return c;
    }

    public static void main(String[] args) {
        System.out.println(firstNotRepeatingChar("abaccdeff"));
    }

}
