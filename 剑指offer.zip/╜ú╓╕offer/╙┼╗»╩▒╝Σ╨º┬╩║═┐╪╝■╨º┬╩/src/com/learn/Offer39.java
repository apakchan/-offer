package com.learn;

import java.util.Random;

public class Offer39 {
    static int moreThanHalfNum(int[] arr, int length) throws Exception {
        if(checkInvalidArray(arr, length))
            return 0;

        int middle = length >> 1;
        int start = 0;
        int end = length - 1;
        int index = partition(arr, length, start, end);
        while (index != middle){
            if (index > middle){
                end = index - 1;
                index = partition(arr, length, start, end);
            }
            else {
                start = index + 1;
                index = partition(arr, length, start, end);
            }
        }
        int res = arr[middle];
        if(!checkMoreThanHalf(arr, length, res))
            res = 0;
        return res;
    }

    static int partition(int[] arr, int length, int start, int end) throws Exception {
        if (arr == null || length <=0 || start < 0 || end >= length)
                throw new Exception("输入错误！");

        int index = (end + start) >> 1;
        int temp = arr[index];
        arr[index] = arr[end];
        arr[end] = temp;

        int small = start - 1;
        for (int i = start; i < end; i++) {
            if(arr[i] < arr[end]){
                small ++;
                if (small != i){
                    int t = arr[i];
                    arr[i] = arr[small];
                    arr[small] = t;
                }
            }
        }

        small ++;
        temp = arr[small];
        arr[small] = arr[end];
        arr[end] = temp;

        return small;
    }

    static boolean checkInvalidArray(int[] arr, int length) {
        boolean inputInvalid = false;
        if (arr == null || length <= 0)
            inputInvalid = true;
        return inputInvalid;
    }

    static boolean checkMoreThanHalf(int[] arr, int length, int number){
        int times = 0;

        for (int i = 0; i < length; i ++)
            if (arr[i] == number)
                times ++;

        return times * 2 > length;
    }

    static int moreThanHalfNum_Simple(int[] arr, int length){
        if(checkInvalidArray(arr, length))
            return 0;

        int res = arr[0];
        int times = 1;
        for (int i = 1; i < length; i ++){
            if (times == 0){
                res = arr[i];
                times = 1;
            }
            else if(arr[i] == res)
                times ++;
            else times --;
        }

        if(!checkMoreThanHalf(arr, length, res))
            res = 0;
        return res;
    }

    public static void main(String[] args) throws Exception {
        int[] arr = {1,2,3,2,2,2,5,4,2};
        int res = moreThanHalfNum_Simple(arr, arr.length);
        System.out.println(res);
    }
}
