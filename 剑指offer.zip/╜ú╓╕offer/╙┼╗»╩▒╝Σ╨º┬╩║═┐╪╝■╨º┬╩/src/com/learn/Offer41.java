package com.learn;

import java.util.Comparator;
import java.util.TreeSet;

public class Offer41 {
    //大根堆
    private TreeSet<Integer> max = new TreeSet<>(new Comparator<Integer>() {
        @Override
        public int compare(Integer o1, Integer o2) {
            return - Integer.compare(o1, o2);
        }
    });

    //小根堆
    private TreeSet<Integer> min = new TreeSet<>(new Comparator<Integer>() {
        @Override
        public int compare(Integer o1, Integer o2) {
            return Integer.compare(o1, o2);
        }
    });

    public void insert(Integer num){
        if(((max.size() + min.size()) & 1) == 0){
            //序列个数为偶数则插入小根堆，同时保证这个数大于大根堆的堆顶元素
            if (max.size() > 0 && num < max.first()){
                int replace = max.first();
                max.remove(replace);
                max.add(num);
                num = replace;
            }
            min.add(num);
        } else {
            //序列个数为奇数则插入大根堆，同时保证这个数小于小根堆的堆顶元素
            if(min.size() > 0 && num > min.first()){
                int replace = min.first();
                min.remove(replace);
                min.add(num);
                num = replace;
            }
            max.add(num);
        }
    }

    public Integer getMid(){
        int size = max.size() + min.size();
        if (size == 0)
            return null;

        Integer mid = 0;
        if ((size & 1) == 1)
            mid = min.first();
        else
            mid = (min.first() + max.first()) >> 1;

        return mid;
    }

    public static void main(String[] args) {
        Offer41 my = new Offer41();
        my.insert(4);
        my.insert(5);
        my.insert(1);
        my.insert(6);
        my.insert(2);
        my.insert(3);
        for (Integer max : my.max) {
            System.out.print(max + " ");
        }
        for (Integer integer : my.min) {
            System.out.print(integer + " ");
        }
    }
}
