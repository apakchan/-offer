package com.learn;

public class Offer43 {
    static int numberOf1Between1AndN(int n){
        if (n <= 0) return 0;

        String s = String.valueOf(n);

        return numberOf1(s);
    }

    private static int numberOf1(String s) {
        if (s == null || 0 >= s.length() || s.charAt(0) < '0' || s.charAt(0) > '9') {
            return 0;
        }
        int first = s.charAt(0) - '0';
        int size = s.length();
        if (size == 1 && first == 0)
            return 0;

        if (size == 1 && first > 0)
            return 1;

        //假设 s 是 21345
        // numFirstDigit 是数字 10000 - 19999的第一位的数目
        int numFirstDigit = 0;
        if (first > 1){
            numFirstDigit = powerBase10(size - 1);
        } else if (first == 1){
            numFirstDigit = Integer.parseInt(s.substring(1)) + 1;
        }

        // 1346 - 21345中除了第一位之外的数位中的数目
        int numOtherDigits = first * (size - 1) * powerBase10(size - 2);
        //1 - 1345中1的个数
        int numRecursive = numberOf1(s.substring(1));

        return numFirstDigit + numOtherDigits + numRecursive;
    }

    private static int powerBase10(int size) {
        int res = 1;
        for (int i = 0; i < size; i++) {
            res *= 10;
        }
        return res;
    }

    public static void main(String[] args) {
        System.out.println(numberOf1Between1AndN(21345));
    }
}
