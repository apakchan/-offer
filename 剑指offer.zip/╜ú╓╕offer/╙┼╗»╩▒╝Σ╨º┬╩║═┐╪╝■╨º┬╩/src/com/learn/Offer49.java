package com.learn;

public class Offer49 {
    static int getUglyNUmber(int index){
        if (index <= 0) return 0;
        int[] uglyNumbers = new int[index];
        uglyNumbers[0] = 1;
        int nextUglyIndex = 1;

        int indexOf2 = 0;
        int indexOf3 = 0;
        int indexOf5 = 0;

        while (nextUglyIndex < index){
            int min = min(uglyNumbers[indexOf2] * 2, uglyNumbers[indexOf3] * 3, uglyNumbers[indexOf5] * 5);
            uglyNumbers[nextUglyIndex] = min;

            while (uglyNumbers[indexOf2] * 2 <= uglyNumbers[nextUglyIndex])
                indexOf2 ++;
            while (uglyNumbers[indexOf3] * 3 <= uglyNumbers[nextUglyIndex])
                indexOf3 ++;
            while (uglyNumbers[indexOf5] * 5 <= uglyNumbers[nextUglyIndex])
                indexOf5 ++;

            ++ nextUglyIndex;
        }

        return uglyNumbers[index - 1];
    }

    private static int min(int i, int i1, int i2) {
        return Math.min(Math.min(i, i1), i2);
    }

    public static void main(String[] args) {
        System.out.println(getUglyNUmber(10));
    }

}
