package com.learn;

public class Offer53_3 {

    static int getNumberSameAsIndex(int[] data, int length){
        if (data == null || length <= 0)
            return -1;

        int l = 0, r = length - 1;
        while (l < r){
            int mid = l + r >> 1;
            if (data[mid] >= mid){
                r = mid;
            } else {
                l = mid + 1;
            }
        }

        if (data[l] != l)
            return -1 ;

        return l;
    }

    public static void main(String[] args) {
        int[] data = {-3, -1, 1, 2, 5};
        System.out.println(getNumberSameAsIndex(data, data.length));
    }

}
