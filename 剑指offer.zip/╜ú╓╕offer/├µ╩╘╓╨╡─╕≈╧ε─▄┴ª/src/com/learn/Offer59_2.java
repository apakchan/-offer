package com.learn;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

public class Offer59_2 {
    static class QueueWithMax{
        private static class InternalData{
            int value;
            int index;
        }
        private final Deque<InternalData> data;
        private final Deque<InternalData> maximums;
        private int currentIndex;

        public QueueWithMax(){
            currentIndex = 0;
            data = new ArrayDeque<>();
            maximums = new ArrayDeque<>();
        }

        public void push_back(int number){
            while (!maximums.isEmpty() && number >= maximums.getLast().value){
                maximums.removeLast();
            }

            InternalData internalData = new InternalData();
            internalData.value = number; internalData.index = currentIndex;
            data.addLast(internalData);
            maximums.addLast(internalData);

            ++ currentIndex;
        }

        public void pop_front() throws Exception {
            if (maximums.isEmpty()){
                throw new Exception("队列为空！");
            }

            if (maximums.getFirst().index == data.getFirst().index)
                maximums.removeFirst();

            data.removeFirst();
        }

        public int max() throws Exception {
            if (maximums.isEmpty()){
                throw new Exception("队列为空！");
            }

            return maximums.getFirst().value;
        }
    }

    public static void main(String[] args) throws Exception {
        QueueWithMax queueWithMax = new QueueWithMax();
        int[] randoms = new int[20];
        for (int i = 0; i < 20; i++) {
           randoms[i] = (int)(Math.random() * 100);
        }
        System.out.println(Arrays.toString(randoms));
        for (int random : randoms) {
            queueWithMax.push_back(random);
        }
        System.out.println(queueWithMax.maximums.getFirst().value);


    }
}
