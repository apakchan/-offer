package com.learn;

import java.util.Arrays;

public class Offer56_2 {

    static int findOnce(int[] data, int length) throws Exception {
        if (data == null || length <= 0)
            throw new Exception("输入错误！");

        int[] bits = new int[32];
        Arrays.fill(bits, 0);
        for (int d : data) {
            int bitMask = 1;
            for (int i = 31; i >= 0; i --){
                if ((d & bitMask) == 1)
                    bits[i] ++;
                bitMask = bitMask << 1;
            }
        }
        int res = 0;
        for (int i = 0; i < 32; i++) {
            res = res << 1;
            if (bits[i] % 3 != 0)
                res += 1;
        }

        return res;
    }

    public static void main(String[] args) throws Exception {
        int[] data = {1, 3, 3, 3, 4, 4, 4};
        System.out.println(findOnce(data, data.length));
    }

}
