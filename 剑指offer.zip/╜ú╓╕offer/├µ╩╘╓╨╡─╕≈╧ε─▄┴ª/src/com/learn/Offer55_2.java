package com.learn;

import java.util.concurrent.atomic.AtomicInteger;

public class Offer55_2 {

    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static int treeDepth(BinaryTreeNode root){
        if (root == null)
            return 0;
        int left = treeDepth(root.lChild);
        int right = treeDepth(root.rChild);
        return Math.max(left, right) + 1;
    }

    static boolean isBalanced_1(BinaryTreeNode root){
        if (root == null)
            return true;

        int left = treeDepth(root.lChild);
        int right = treeDepth(root.rChild);
        int sub = Math.abs(left - right);
        if (sub > 1)
            return false;

        return isBalanced_1(root.lChild) && isBalanced_1(root.rChild);
    }
    
    static boolean isBalancedEntrance(BinaryTreeNode root){
        AtomicInteger depth = new AtomicInteger(0);
        return isBalanced_2(root, depth);
    }
    
    static boolean isBalanced_2(BinaryTreeNode root, AtomicInteger depth){
        if (root == null){
            depth.compareAndSet(depth.intValue(), 0);
            return true;
        }
        
        AtomicInteger left = new AtomicInteger(), right = new AtomicInteger();
        if (isBalanced_2(root.lChild, left) && isBalanced_2(root.rChild, right)){
            
            int diff = Math.abs(left.intValue() - right.intValue());
            
            if (diff <= 1){
                depth.compareAndSet(depth.intValue(), 1 + Math.max(left.intValue(), right.intValue()));
                System.out.println("value: " + root.value + ", depth: " + depth.intValue());
                return true;
            }
        }
        
        return false;
    }
    
    public static void main(String[] args) {
        BinaryTreeNode left = new BinaryTreeNode(2, new BinaryTreeNode(4, null, null),
                new BinaryTreeNode(5, new BinaryTreeNode(7, null, null), null));
        BinaryTreeNode right = new BinaryTreeNode(3, null, new BinaryTreeNode(6, null, null));
        BinaryTreeNode root = new BinaryTreeNode(1,left, right);

        System.out.println(isBalancedEntrance(root));
    }
    
}
