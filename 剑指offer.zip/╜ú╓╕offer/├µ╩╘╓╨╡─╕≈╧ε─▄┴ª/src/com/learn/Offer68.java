package com.learn;

import java.util.ArrayList;
import java.util.List;

public class Offer68 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static boolean getNodePath(BinaryTreeNode root, BinaryTreeNode node, List<BinaryTreeNode> path){
        if (root == node)
            return true;

        path.add(root);
        boolean found = false;
        if (root.lChild != null)
            found = found || getNodePath(root.lChild, node, path);
        if (root.rChild != null)
            found = found ||getNodePath(root.rChild, node, path);

        if (!found)
            path.remove(path.size() - 1);

        return found;
    }

    static BinaryTreeNode getLastCommonNode(List<BinaryTreeNode> path1, List<BinaryTreeNode> path2){
        BinaryTreeNode node = null;

        for (int i = 0; i < path1.size() && i < path2.size(); i++) {
            if (path1.get(i) != path2.get(i)) {
                node = path1.get(i - 1);
                break;
            }
        }
        return node;
    }

    static BinaryTreeNode getLastCommonParent(BinaryTreeNode root, BinaryTreeNode node1, BinaryTreeNode node2){
        if (root == null || node1 == null || node2 == null)
            return null;

        List<BinaryTreeNode> path1 = new ArrayList<>();
        getNodePath(root, node1, path1);

        List<BinaryTreeNode> path2 = new ArrayList<>();
        getNodePath(root, node2, path2);

        return getLastCommonNode(path1, path2);
    }

    public static void main(String[] args) {
        BinaryTreeNode node1 = new BinaryTreeNode(6, null, null);
        BinaryTreeNode node2 = new BinaryTreeNode(8, null, null);

        BinaryTreeNode root = new BinaryTreeNode(1, new BinaryTreeNode(2
                , new BinaryTreeNode(4, node1, new BinaryTreeNode(7, null, null))
                , new BinaryTreeNode(5, node2, new BinaryTreeNode(9, null, null)))
                , new BinaryTreeNode(3, null, null));

//        getLastCommonParent(root, node1, node2);
        System.out.println(getLastCommonParent(root, node1, node2).value);
    }
}
