package com.learn;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Offer65 {
    static int getSum(int a, int b){
        int sum, carry;
        do {
            sum = (a ^ b);
            //左移是因为产生进位了。
            carry = (a & b) << 1;
            a = sum;
            b = carry;
        } while (carry != 0);

        return sum;
    }

    public static void main(String[] args) {
        System.out.println(getSum(1, 2));
    }

}
