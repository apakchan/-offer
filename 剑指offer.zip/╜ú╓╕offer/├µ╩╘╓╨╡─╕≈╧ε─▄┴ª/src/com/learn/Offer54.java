package com.learn;

import java.util.concurrent.atomic.AtomicInteger;

public class Offer54 {

    private static int index = 0;

    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static BinaryTreeNode kthNode(BinaryTreeNode root, int k){
        if (root == null || k <= 0)
            return null;

        AtomicInteger num = new AtomicInteger(k);

        return dfs(root, num);
    }

    static BinaryTreeNode dfs(BinaryTreeNode father, AtomicInteger k) {
        BinaryTreeNode p = null;

        if (father.lChild != null)
            p = dfs(father.lChild, k);

        if (p == null){
            if (k.intValue() == 1)
                p = father;

            k.decrementAndGet();
        }

        if (p == null && father.rChild != null){
            p = dfs(father.rChild, k);
        }

        return  p;
    }

    public static void main(String[] args) {
        BinaryTreeNode left = new BinaryTreeNode(3,
                new BinaryTreeNode(2, null, null),
                new BinaryTreeNode(4, null, null));
        BinaryTreeNode right = new BinaryTreeNode(7,
                new BinaryTreeNode(6, null, null),
                new BinaryTreeNode(8, null, null));
        BinaryTreeNode root = new BinaryTreeNode(5, left, right);
        if (kthNode(root, 3) != null)
            System.out.println(kthNode(root, 3).value);
    }

}
