package com.learn;

public class Offer55_1 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static int treeDepth(BinaryTreeNode root){
        if (root == null)
            return 0;

        int left = treeDepth(root.lChild);
        int right = treeDepth(root.rChild);

        return Math.max(left, right) + 1;
    }

    public static void main(String[] args) {
        BinaryTreeNode left = new BinaryTreeNode(2, new BinaryTreeNode(4, null, null),
                new BinaryTreeNode(5, new BinaryTreeNode(7, null, null), null));
        BinaryTreeNode right = new BinaryTreeNode(3, null, new BinaryTreeNode(6, null, null));
        BinaryTreeNode root = new BinaryTreeNode(1, left, right);

        System.out.println(treeDepth(root));
    }

}
