package com.learn;

import java.util.List;

public class Offer58_1 {
    static String reverse(String str){
        StringBuilder sb = new StringBuilder(str.length());
        StringBuilder temp = new StringBuilder();
        for (int i = str.length() - 1; i >= 0; i --) {
            if (str.charAt(i) != ' ') {
                temp.append(str.charAt(i));
            } else {
                temp.reverse();
                sb.append(temp).append(" ");
                temp = new StringBuilder(str.length() - i);
            }
        }
        temp.reverse();
        sb.append(temp);
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(reverse("is ab stu"));
    }
}
