package com.learn;

public class Offer63 {
    static Integer getMaxDiff(int[] arr, int length){
        if (arr == null || length < 2)
            return null;

        int min = arr[0];
        int maxDiff = arr[1] - arr[0];

        for (int i = 2; i < length; i++) {
            if (arr[i - 1] < min)
                min = arr[i - 1];

            int currentDiff = arr[i] - min;
            if (currentDiff > maxDiff)
                maxDiff = currentDiff;
        }

        return maxDiff;
    }

    public static void main(String[] args) {

        System.out.println(getMaxDiff(new int[]{9, 11, 8, 5, 7, 12, 16, 14}, 8));
    }
}
