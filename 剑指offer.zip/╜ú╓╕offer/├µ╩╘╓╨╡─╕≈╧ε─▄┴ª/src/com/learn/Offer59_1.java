package com.learn;

import java.util.*;

public class Offer59_1 {
    static List<Integer> maxInWindows(List<Integer> num, int size){
        if (num == null || size <= 0)
            return null;

        List<Integer> res = new ArrayList<>();
        Deque<Integer> index = new ArrayDeque<>();
        for (int i = 0; i < size; i++) {
            //添加元素前与队尾元素比较，如果大于队尾元素则删除队尾元素，最后再添加进来
            while (!index.isEmpty() && num.get(i) >= num.get(index.getLast())){
                index.removeLast();
            }
            index.push(i);
        }

        for (int i = size; i < num.size(); i++) {
            res.add(num.get(index.getFirst()));

            while (!index.isEmpty() && num.get(i) >= num.get(index.getLast())){
                index.removeLast();
            }
            //删除掉出滑动窗口的元素下标
            while (!index.isEmpty() && index.getFirst() <= (i - size)){
                index.removeFirst();
            }
            index.addLast(i);
        }
        res.add(num.get(index.getFirst()));

        return res;
    }

    public static void main(String[] args) {
        List<Integer> num = Arrays.asList(2, 3, 4, 2, 6, 2, 5, 1);
        List<Integer> integers = maxInWindows(num, 3);
        System.out.println(integers);
    }
}
