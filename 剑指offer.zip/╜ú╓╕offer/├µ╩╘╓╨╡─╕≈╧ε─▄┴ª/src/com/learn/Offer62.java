package com.learn;

import java.util.LinkedList;
import java.util.List;

public class Offer62 {
    static int getLast(int n, int m){
        if (n < 1 || m < 1)
            return -1;
        List<Integer> l = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            l.add(i);
        }

        int index = 0;
        while (l.size() > 1){
            for (int i = 1; i < m; i++) {
                index ++;
                if (index >= l.size())
                    index = index % l.size();
            }

            l.remove(index);
        }

        return l.get(0);
    }

    static int getLast_Math(int n, int m){
        if (n < 1 || m < 1)
            return -1;

        int last = 0;
        for (int i = 2; i <= n; i++) {
            last = (last + m) % i;
        }
        return last;
    }

    public static void main(String[] args) {
        System.out.println(getLast_Math(5, 3));
    }
}
