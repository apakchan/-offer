package com.learn;

import java.util.List;

public class Offer66 {
    static void multiply(double[] arr1, double[] arr2){
        int length1 = arr1.length;
        int length2 = arr2.length;

        if (length1 == length2 && length2 > 1){
            arr2[0] = 1;
            for (int i = 1; i < length1; i++) {
                arr2[i] = arr2[i - 1] * arr1[i - 1];
            }

            double temp = 1;
            for (int i = length1 - 2; i >= 0; i --) {
                temp *= arr1[i + 1];
                arr2[i] *= temp;
            }
        }
    }

    public static void main(String[] args) {
        double[] arr1 = {1, 2, 3, 4, 5};
        double[] arr2 = new double[arr1.length];
        multiply(arr1, arr2);
        for (double v : arr2) {
            System.out.print(v + " ");
        }
    }
}
