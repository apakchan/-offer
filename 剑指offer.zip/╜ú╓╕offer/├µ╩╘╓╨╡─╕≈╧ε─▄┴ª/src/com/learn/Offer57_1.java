package com.learn;

import java.util.ArrayList;
import java.util.List;

public class Offer57_1 {

    static List<Integer> findSumIsS(int[] data, int length, int s){
        if (data == null || length <= 0)
            return null;

        List<Integer> l = new ArrayList<>();

        int i = 0, j = length - 1;
        while (i < j){
            int sum = data[i] + data[j];
            if (sum > s){
                j --;
            } else if (sum < s){
                i ++;
            } else{
                l.add(i);
                l.add(j);
                break;
            }
        }
        if (l.size() < 2)
            return null;
        return l;
    }

    public static void main(String[] args) {
        int[] data = {1, 2, 4, 7, 11, 15};
        List<Integer> l = findSumIsS(data, data.length, 15);
        if (l != null)
            l.forEach((e) -> {
                System.out.print(e + " ");
            });
    }
}
