package com.learn;

public class Offer67 {
    static Integer getNumber(String s){
        if (s == null || s.length() == 0)
            return null;

        long number = 0;
        boolean minus = false;
        if (s.charAt(0) == '+')
            minus = false;
        else if (s.charAt(0) == '-')
            minus = true;
        else {
            minus = false;
            number += s.charAt(0) - '0';
        }
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) > '9' || s.charAt(i) < '0')
                return null;

            number = number * 10 + s.charAt(i) - '0';
            if (number > Integer.MAX_VALUE || number < Integer.MIN_VALUE)
                return null;
        }


        return minus? -(int)number : (int)number;
    }

    public static void main(String[] args) {
        System.out.println(getNumber("123123"));
    }
}
