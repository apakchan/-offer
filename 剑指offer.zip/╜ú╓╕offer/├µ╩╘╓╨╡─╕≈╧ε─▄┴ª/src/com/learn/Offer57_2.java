package com.learn;

import java.util.ArrayList;
import java.util.List;

public class Offer57_2 {
    static List<List<Integer>> findContinuousSequence(int s){
        if (s < 3)
            return null;
        List<List<Integer>> res = new ArrayList<>();

        int l = 1, r = 2;
        int curSum = l + r;
        while (l < (s + 1) / 2){
            if (curSum == s) {
                List<Integer> list = new ArrayList<>();
                for (int i = l; i <= r; i++) {
                    list.add(i);
                }
                res.add(list);
            }

            while (curSum > s && l < (s + 1) / 2) {
                curSum -= l;
                l ++;

                if (curSum == s){
                    List<Integer> list = new ArrayList<>();
                    for (int i = l; i <= r; i++) {
                        list.add(i);
                    }
                    res.add(list);
                }
            }

            r ++;
            curSum += r;
        }

        if (res.size() == 0)
            return null;

        return res;
    }

    public static void main(String[] args) {
        List<List<Integer>> list = findContinuousSequence(15);
        if (list != null) {
            list.forEach(System.out :: println);
        }
    }
}
