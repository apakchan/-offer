package com.learn;

import java.util.Arrays;

public class Offer61 {
    static boolean isShunZi(int[] arr){
        if (arr == null)
            return false;

        Arrays.sort(arr);
        int countOf0 = 0;
        int div = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0)
                countOf0 ++;
            if (i + 1 < arr.length && arr[i] != 0)
                div += (arr[i + 1] - arr[i]) - 1;
            if (i + 1 < arr.length && arr[i + 1] == arr[i] && arr[i] != 0)
                return false;
        }

        if (div > countOf0)
            return false;

        return true;
    }

    public static void main(String[] args) {
        int[] arr = {2, 2, 3, 4, 5, 8, 0};
        System.out.println(isShunZi(arr));
    }
}
