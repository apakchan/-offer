package com.learn;

public class Offer56_1 {

    static void findNumsAppearOnce(int[] data, int length, int[] answer){
        if (data == null || length < 2)
            return;

        int resOfXOR = 0;
        for (int datum : data) {
            resOfXOR ^= datum;
        }
        int indexOf1 = findFirstBitIs1(resOfXOR);

        answer[0] = 0;
        answer[1] = 0;

        for (int i = 0; i < length; i++) {
            if (isBit1(data[i], indexOf1))
                answer[0] ^= data[i];
            else
                answer[1] ^= data[i];
        }
    }

    //判断第 n 位是否为1
    private static boolean isBit1(int num, int index) {
        num = num >> index;
        return (num & 1) == 1;
    }

    //找到第一位为 1 的数字
    private static int findFirstBitIs1(int num) {
        int index = 0;
        while ((num & 1) == 0){
            num = num >> 1;
            index ++;
        }
        return index;
    }

    public static void main(String[] args) {
        int[] data = {2, 4, 3, 6, 3, 2, 5, 5};
        int[] ans = new int[2];
        findNumsAppearOnce(data, data.length, ans);
        System.out.println(ans[0] + " " + ans[1]);
    }
}
