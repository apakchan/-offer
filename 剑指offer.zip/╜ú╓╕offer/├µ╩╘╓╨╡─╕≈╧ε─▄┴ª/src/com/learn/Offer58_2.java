package com.learn;

public class Offer58_2 {
    static String leftRoatateString(String str, int k){
        if (str == null || k > str.length())
            return null;
        StringBuilder sb = new StringBuilder(str.length());
        sb.append(str.substring(k));
        sb.append(str, 0, k);
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(leftRoatateString("asdf", 4));
    }
}
