package com.learn;

public class Offer53_1 {
    static int getNumberOfK(int[] data, int length, int value){
        if (data == null || length <= 0)
            return 0;

        int number = 0;

        int indexOfLeft = getIndexOfLeft(data, length, value);
        if (indexOfLeft == -1)
            return 0;
        int indexOfRight = getIndexOfRight(data, length, value);
        number = indexOfRight - indexOfLeft + 1;

        return number;
    }

    private static int getIndexOfLeft(int[] data, int length, int value) {
        int l = 0, r = length - 1;

        while (l < r){
            int mid = (l + r) >> 1;
            if (data[mid] >= value){
                r = mid;
            } else {
                l = mid + 1;
            }
        }

        if (data[l] != value)
            return -1;

        return l;
    }

    private static int getIndexOfRight(int[] data, int length, int value){
        int l = 0, r = length - 1;

        while (l < r){
            int mid = (l + r + 1) >> 1;
            if (data[mid] <= value){
                l = mid;
            } else {
                r = mid - 1;
            }
        }

        if (l != r)
            return -1;

        return l;
    }

    public static void main(String[] args) {
        int[] data = {1, 2, 3, 3, 3, 3, 4, 5};
        System.out.println(getIndexOfLeft(data, data.length, 3));
        System.out.println(getIndexOfRight(data, data.length, 3));
        System.out.println(getNumberOfK(data, data.length, 3));
    }
}
