package com.learn;

public class Offer53_2 {
    static int getMissingNumber(int[] data, int length){
        if (data == null || length <= 0)
            return -1;

        int l = 0, r = length - 1;
        while (l < r){
            int mid = l + r >> 1;
            if(data[mid] != mid){
                r = mid;
            } else {
                l = mid + 1;
            }
        }

        return l;
    }

    public static void main(String[] args) {
        int[] data = {0, 1, 6, 2, 3};
        System.out.println(getMissingNumber(data, data.length));
    }

}
