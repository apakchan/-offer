package com.learn;

public class Offer64 {

    static int getSum(int n){
        boolean b = (n > 0) && (n += getSum(n - 1)) > 0;
        return n;
    }

    public static void main(String[] args) {
        System.out.println(getSum(5));
    }
}
