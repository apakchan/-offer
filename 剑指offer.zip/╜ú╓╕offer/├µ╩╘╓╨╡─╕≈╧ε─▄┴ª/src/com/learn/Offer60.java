package com.learn;

import java.util.Arrays;

public class Offer60 {
    static void printProbability(int number){
        if (number < 1)
            return;

        int maxSum = 6 * number;
        int[] probabilities = new int[maxSum - number + 1];
        Arrays.fill(probabilities, 0);

        probability(number, probabilities);

        int total = (int) Math.pow(6, number);
        for (int i = number; i <= maxSum; i++) {
            double ratio = (double) probabilities[i - number] / total;
            System.out.println(i + ": " + ratio);
        }
    }

    private static void probability(int number, int[] probabilities) {
        for (int i = 1; i <= 6; i++) {
            probability(number, number, i, probabilities);
        }
    }

    /**
     *
     * @param original 初始骰子数目
     * @param current 骰子被分成两堆，一堆是1，这个参数是另一堆的骰子数量
     * @param sum 当前递归状态下的点数之和
     * @param probabilities 数组
     */
    private static void probability(int original, int current, int sum, int[] probabilities) {
        if (current == 1){
            probabilities[sum - original] ++;
        } else {
            for (int i = 1; i <= 6; i++) {
                probability(original, current - 1, i + sum, probabilities);
            }
        }
    }

    static void printProbability_DP(int number){
        if (number < 1)
            return;

        int[][] probabilities = new int[2][6 * number + 1];
        Arrays.fill(probabilities[0], 0);
        Arrays.fill(probabilities[1], 0);

        int flag = 0;
        for (int i = 1; i <= 6; i++) {
            probabilities[flag][i] = 1;
        }

        for (int k = 2; k <= number; k++) {
            for (int i = 0; i < k; i++) {
                probabilities[1 - flag][i] = 0;
            }

            for (int i = k; i <= 6 * k; i++) {
                probabilities[1 - flag][i] = 0;
                for (int j = 1; j <= i && j <= 6; j++) {
                    probabilities[1 - flag][i] += probabilities[flag][i - j];
                }
            }

            flag = 1 - flag;
        }

        int total = (int) Math.pow(6, number);
        for (int i = number; i <= 6 * number; i++) {
            double ratio = (double) probabilities[flag][i] / total;
            System.out.println(i + ": " + ratio);
        }
    }

    public static void main(String[] args) {
        printProbability_DP(2);
    }
}
