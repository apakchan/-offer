package com.learn;

import java.util.*;

public class Offer3 {

    public static boolean duplicate(int[] arr, int length, List<Integer> ans){
        if(arr == null || length <= 0) return false;

        for (int i : arr) {
            if (i > length - 1 || i < 0) return false;
        }

        Set<Integer> set = new HashSet<>();
        for(int i = 0; i < length; i ++){

            while (arr[i] != i){

                if(arr[i] == arr[arr[i]]){
                    set.add(arr[i]);
                    break;
                }

                int temp = arr[i];
                arr[i] = arr[temp];
                arr[temp] = temp;
            }
        }

        ans.addAll(set);

        return true;
    }

    public static void main(String[] args) {
        int[] arr = new int[]{2,3,1,0,2,5,3};
        List<Integer> l = new ArrayList<>();
        if(duplicate(arr, 7, l)){
            System.out.println(l);
        } else {
            try {
                throw new Exception("格式错误");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
