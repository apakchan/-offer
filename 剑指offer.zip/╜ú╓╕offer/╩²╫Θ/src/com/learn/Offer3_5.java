package com.learn;

public class Offer3_5 {

    public static int getDuplication(int[] arr, int length){
        if(arr == null || length <= 0)
            return -1;

        for (int i : arr) {
            if(i <= 0 || i > length - 1) return -1;
        }

        int start = 1;
        int end = length - 1;
        while(end >= start) {
            int mid = ((end - start) >> 1) + start;  //得到中间数 m
            int count = getCount(arr, length,start, mid);  //得到 start - mid 的数量
            if(end == start){  //如果二分到只剩一个
                if(count > 1)  //得到重复的数字
                    return start;
                else
                    break;
            }
            if(count > (mid - start + 1))  //如果数量大于 start - mid 的个数 那么说明 start-mid 中一定有重复的，那么此时范围就是 start - mid
                end = mid;
            else   //否则范围为 mid + 1 - end
                start = mid + 1;
        }
        return -1;
    }

    public static int getCount(int[] arr, int length, int start, int end){

        if(arr == null)
            return 0;

        int count = 0;
        for(int i = 0; i < length; i ++)
            if(arr[i] >= start && arr[i] <= end)
                count ++;

        return count;
    }

    public static void main(String[] args) {
        int[] arr = new int[]{2, 3, 5, 4, 3, 2, 6, 7};
        int ans = getDuplication(arr, 8);
        if(ans == -1){
            System.out.println("输入格式有误");
        } else {
            System.out.println(ans);
        }
    }
}
