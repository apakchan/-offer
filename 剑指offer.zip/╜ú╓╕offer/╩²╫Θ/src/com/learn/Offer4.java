package com.learn;

import java.nio.file.Paths;

public class Offer4 {

    static boolean find(int[] arr, int rows, int columns, int number){
        boolean found = false;

        if(arr != null && rows > 0 && columns > 0){
            int row = 0;
            int column = columns - 1;
            while(row < rows && column < columns){
                if(arr[row * columns + column] == number){  //如果右上角的数与要找的数相等
                    found = true;
                    break;
                } else if(arr[row * columns + column] > number)  //如果右上角的数大于要找的数，则列指针左移
                    column --;
                else  //右上角的数小于要找的数，则行指针下移
                    row ++;
            }
        }

        return found;
    }

    public static void main(String[] args) {
         int[] arr = new int[]{
                 1, 2, 8, 9,
                 2, 4, 9, 12,
                 4, 7, 10, 14,
                 6, 8, 11, 15
         };
         if(find(arr, 4, 4, 7))
             System.out.println(true);
    }
}
