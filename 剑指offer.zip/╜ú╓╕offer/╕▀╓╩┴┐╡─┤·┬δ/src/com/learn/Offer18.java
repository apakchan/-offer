package com.learn;


public class Offer18 {
    static class MyNode{
        int value;
        MyNode next;
    }
    static void deleteNode(MyNode pListHead, MyNode pTobeDeleted){
        if(pListHead == null || pTobeDeleted == null) return;

        if(pTobeDeleted.next != null){
            //如果这个节点不是尾结点
            pTobeDeleted.value = pTobeDeleted.next.value;
            pTobeDeleted.next = pTobeDeleted.next.next;
            //这里采用复制节点法
        } else if (pListHead == pTobeDeleted){
            //如果这个链表只有一个节点
            pListHead = null;
            pTobeDeleted = null;
        } else {
            //链表有多个节点且这个节点是尾结点
            MyNode p = pListHead;
            while (p.next != pTobeDeleted){
                p = p.next;
            }
            p.next = null;
            pTobeDeleted = null;
        }
    }

    static void deleteDuplication(MyNode pHead){
        if(pHead == null) return;

        MyNode dummy = new MyNode();
        dummy.next = pHead;

        MyNode pPreNode = dummy;
        MyNode pNode = pHead;

        while (pNode != null){
            boolean needDeleted = false;
            MyNode pNext = pNode.next;

            if(pNext != null && pNext.value == pNode.value){
                needDeleted = true;
            }

            if(!needDeleted){
                pPreNode = pPreNode.next;
                pNode = pNode.next;
            } else {
                while (pNext != null && pNode.value == pNext.value){
                    pNode = pNode.next;
                    pNext = pNext.next;
                }
                pNode = pNext;
                pPreNode.next = pNode;
            }
        }
    }
}
