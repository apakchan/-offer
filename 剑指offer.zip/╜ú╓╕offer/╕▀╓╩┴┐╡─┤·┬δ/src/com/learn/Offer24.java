package com.learn;

public class Offer24 {
    static class MyNode{
        int value;
        MyNode next;

        public MyNode() {
        }

        public MyNode(int value, MyNode next) {
            this.value = value;
            this.next = next;
        }
    }

    static MyNode reverseListNode(MyNode pHead){
        if(pHead == null) return null;

        if (pHead.next == null) return pHead;  //链表中只有 1个节点

        MyNode p = pHead;
        MyNode q = p.next;
        MyNode r = q.next;

        boolean isFirst = true;
        while (q != null){
            q.next = p;
            if (isFirst){
                p.next = null;
                isFirst = false;
            }
            p = q;
            q = r;
            if (r != null)
                r = r.next;
        }

        return p;
    }

    static void print(MyNode head){
        MyNode p = head;
        while (p != null){
            System.out.print(p.value + " ");
            p = p.next;
        }
        System.out.println();
    }


    public static void main(String[] args) {
        MyNode head = new MyNode(1,new MyNode(2, new MyNode(3, new MyNode(4, new MyNode(5, new MyNode(6, null))))));
        print(reverseListNode(head));
    }
}
