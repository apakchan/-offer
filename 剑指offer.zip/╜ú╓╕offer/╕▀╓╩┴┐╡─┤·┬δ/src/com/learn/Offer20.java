package com.learn;

import java.util.concurrent.atomic.AtomicInteger;

public class Offer20 {
    static boolean isNumeric(String str){
        if(str == null)
            return false;

        AtomicInteger index = new AtomicInteger(0);

        boolean numeric = scanInteger(str, index);

        //如果出现小数点，那么后面只有数字部分
        if(index.intValue() < str.length() && str.charAt(index.intValue()) == '.'){
            index.incrementAndGet();

            //1.小数可以没有整数部分，如.123等于 0.123
            //2.小数点后面可以没有数字，如 233.等于 233.0
            //3.小数点前后都可以有数字，如 233.666
            numeric = onlyScanNumber(str, index) || numeric;
        }

        //如果出现 e 或者 E接下来是指数部分
        if(index.intValue() < str.length() && (str.charAt(index.intValue()) == 'e' || str.charAt(index.intValue()) == 'E')){
            index.incrementAndGet();

            //1.e前面没有数字时不可以
            //2.e后面没有整数时，不可以
            numeric = numeric && scanInteger(str, index);
        }

        return numeric && index.intValue() == str.length();
    }

    //扫描带正负号的数字
    static boolean scanInteger(String str, AtomicInteger index) {
        if (index.intValue() < str.length() && str.charAt(index.intValue()) == '+' || str.charAt(index.intValue()) == '-')
            index.incrementAndGet();
        return onlyScanNumber(str, index);
    }

    //只扫描数字
    static boolean onlyScanNumber(String str, AtomicInteger index) {
        int before = index.intValue();

        while (index.intValue() < str.length() && (str.charAt(index.intValue()) >= '0' && str.charAt(index.intValue()) <= '9')){
            index.incrementAndGet();
        }

        return before < index.intValue();
    }

    public static void main(String[] args) {
        System.out.println(isNumeric("1.2"));
    }
}
