package com.learn;

import java.util.Random;

public class Offer21 {

    static void reorderOddEven(int[] data, int length){
        if(data == null || length <= 0) return;

        int p1 = 0, p2 = length - 1;
        while (p1 < p2){
            while (p1 < p2 && data[p1] % 2 != 0) p1 ++;
            while (p1 < p2 && data[p2] % 2 == 0) p2 --;

            int temp = data[p1];
            data[p1] = data[p2];
            data[p2] = temp;
        }
    }

    public static void main(String[] args) {
        Random r = new Random();
        int[] data = new int[10];

        for (int i = 0; i < 10; i++) {
            data[i] = r.nextInt(100);
        }

        for (int datum : data) {
            System.out.print(datum + " ");
        }

        System.out.println();

        reorderOddEven(data, data.length);

        for (int datum : data) {
            System.out.print(datum + " ");
        }
    }
}
