package com.learn;

public class Offer25 {
    static class MyNode{
        int value;
        MyNode next;

        public MyNode() {
        }

        public MyNode(int value, MyNode next) {
            this.value = value;
            this.next = next;
        }
    }

    static MyNode merge(MyNode listA, MyNode listB){
        if(listA == null && listB == null) return null;
        if(listA == null) return listB;
        if(listB == null) return listA;
        MyNode listC = new MyNode();
        MyNode head = listC;
        while (listA != null && listB != null){
            if(listA.value < listB.value){
                listC.next = listA;
                listC = listC.next;
                listA = listA.next;
            } else {
                listC.next = listB;
                listC = listC.next;
                listB = listB.next;
            }
        }
        if(listA != null) {
            listC.next = listA;
        }

        if(listB != null){
            listC.next = listB;
        }
        return head.next;
    }

    public static void main(String[] args) {
        MyNode listA = new MyNode(1, new MyNode(3, new MyNode(5, new MyNode(7, null))));
        MyNode listB = new MyNode(2, null);
        MyNode head = merge(listA, listB);
        while (head != null){
            System.out.print(head.value + " ");
            head = head.next;
        }
    }
}
