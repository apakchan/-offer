package com.learn;

import java.util.Arrays;

public class Offer17 {
    static void printToMax_1(int n){
        int number = 1;
        int i = 0;
        while (i < n){
            number *= 10;
            i ++;
        }
        for(i = 1; i < number; i ++)
            System.out.print(i + " ");
    }

    static void printToMax_2(int n){
        if(n <= 0) return;
        char[] number = new char[n];
        Arrays.fill(number, '0');
        while(!increment(number)){
            printNumber(number);
        }
    }



    private static boolean increment(char[] number) {
        boolean isOverflow = false;  //是否满溢
        int nTakeOver = 0;  //进位标记
        int length = number.length;
        for(int i = length - 1; i >= 0; i --) {
            int nSum = number[i] - '0' + nTakeOver;  //加上进位
            if(i == length - 1)  //由于是自增，因此最后一位加 1
                nSum ++;
            if(nSum >= 10){  //如果这位进位
                if(i == 0)  //如果最后一位进位那么溢出
                    isOverflow = true;
                else {
                    nSum -= 10;
                    nTakeOver = 1;
                    number[i] = (char) ('0' + nSum);
                }
            } else {
                number[i] = (char)('0' + nSum);
                break;
            }
        }
        return isOverflow;
    }

    private static void printNumber(char[] number) {
        boolean isBeginning = true;
        for(int i = 0; i < number.length; i ++){
            if(isBeginning && number[i] != '0'){
                isBeginning = false;
            }

            if(!isBeginning)
                System.out.print(number[i]);
        }
        System.out.print(" ");
    }

    static void printToMax_3(int n){
        if(n <= 0) return;
        char[] number = new char[n];

        for(int i = 0; i < 10; i ++){
            number[0] = (char) (i +'0');
            printToMaxRe(number, n, 0);
        }
    }

    private static void printToMaxRe(char[] number, int n, int index) {
        if(index == n - 1) {
            printNumber(number);
            return;
        }

        for(int i = 0; i < 10; i ++){
            number[index + 1] = (char) (i + '0');
            printToMaxRe(number, n, index + 1);
        }
    }

    public static void main(String[] args) {
        printToMax_3(2);
    }
}
