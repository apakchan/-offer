package com.learn;

public class Offer16 {

    static double powerSimple(double base, int exponent){
        double res = 1.0;

        for(int i = 0; i < exponent; i ++){
            res *= base;
        }

        return res;
    }

    private static boolean invalidInput = false;

    static double powerMid(double base, int exponent){
        invalidInput = false;

        //如果base = 0，并且指数小于0
        if(Double.compare(base, 0) == 0 && exponent < 0){
            invalidInput = true;
            return 0;
        }

        int absExponent = Math.abs(exponent);
        if(exponent < 0){  //如果指数小于零，返回指数大于 0的倒数即可
            return 1.0 / powerSimple(base, absExponent);
        } else {
            return powerSimple(base, absExponent);
        }
    }

    static double powerQuick(double base, int exponent){
        if(exponent == 0)
            return 1;
        if(exponent == 1)
            return base;

        double res = powerQuick(base, exponent >> 1);
        res *= res;

        if((exponent & 0x1) == 1)
            res *= base;

        return res;
    }


    public static void main(String[] args) {
        System.out.println(powerMid(2.0, -10));
    }
}
