package com.learn;

public class Offer22 {

    static class MyNode{
        int value;
        MyNode next;

        public MyNode() {
        }

        public MyNode(int value, MyNode next) {
            this.value = value;
            this.next = next;
        }
    }

    static MyNode findKthToTail(MyNode head, int k){
        if(head == null || k <= 0) return null;

        MyNode pAhead = head;
        MyNode pBehind = head;

        for(int i = 0; i < k - 1; i ++){
            if(pAhead.next == null)
                return null;
            pAhead = pAhead.next;
        }

        while (pAhead.next != null){
            pAhead = pAhead.next;
            pBehind = pBehind.next;
        }
        return pBehind;
    }

    public static void main(String[] args) {
        MyNode node = new MyNode(1, new MyNode(2, new MyNode(3, new MyNode(4, new MyNode(5, new MyNode(6, null))))));

        System.out.println(findKthToTail(node, 1).value);
    }
}
