package com.learn;

public class Offer23 {
    static class MyNode{
        int value;
        MyNode next;

        public MyNode() {
        }

        public MyNode(int value, MyNode next) {
            this.value = value;
            this.next = next;
        }
    }

    static MyNode circleEntrance(MyNode pHead){
        if(pHead == null) return null;

        if(circleNum(pHead) == 0)
            return null;

        int circleNum = circleNum(pHead);  //环中节点个数
        MyNode pAhead = pHead;
        MyNode pBehind = pHead;

        for(int i = 0; i < circleNum; i ++){
            pAhead = pAhead.next;
        }

        while(pAhead != pBehind){
            pAhead = pAhead.next;
            pBehind = pBehind.next;
        }
        return pAhead;
    }

    /**
     *
     * @param pHead 头指针
     * @return 返回 0 代表没有环，返回 -1 代表输入错误
     */
    static int circleNum(MyNode pHead){
        if (pHead == null) return -1;

        MyNode pFast = pHead;
        MyNode pSlow = pHead;

        while (pFast != null && pSlow != null){
            pSlow = pSlow.next;
            pFast = pFast.next;
            if(pFast == null) return 0;
            pFast = pFast.next;
            if (pFast == pSlow)
                break;
        }

        if (pFast == null) return 0;

        MyNode meetNode = pFast;  //记录相遇的节点
        pFast = pFast.next;
        int num = 1;
        while (pFast != meetNode){
            num ++;
            pFast = pFast.next;
        }

        return num;
    }



    public static void main(String[] args) {
        MyNode node1 = new MyNode();
        MyNode node2 = new MyNode();
        MyNode node3 = new MyNode();
        MyNode node4 = new MyNode();
        MyNode node5 = new MyNode();
        MyNode node6 = new MyNode();
        node1.value = 1;
        node2.value = 2;
        node3.value = 3;
        node4.value = 4;
        node5.value = 5;
        node6.value = 6;
        node1.next = node2;
        node2.next = node3;
        node3.next = node4;
        node4.next = node5;
        node5.next = node6;
//        node6.next = node3;
        System.out.println(circleEntrance(node1));
    }
}
