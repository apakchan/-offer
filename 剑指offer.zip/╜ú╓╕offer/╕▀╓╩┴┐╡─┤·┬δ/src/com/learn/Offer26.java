package com.learn;

public class Offer26 {
    static class BinaryTreeNode{
        double value;
        BinaryTreeNode leftChild;
        BinaryTreeNode rightChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(double value, BinaryTreeNode leftChild, BinaryTreeNode rightChild) {
            this.value = value;
            this.leftChild = leftChild;
            this.rightChild = rightChild;
        }
    }

    static boolean hasSubtree(BinaryTreeNode pRoot1, BinaryTreeNode  pRoot2){
        boolean res = false;

        if(pRoot1 != null && pRoot2 != null){
            if(Double.compare(pRoot1.value, pRoot2.value) == 0){
                res = doesTree1HasTree2(pRoot1, pRoot2);
            }
            if (!res){
                res = hasSubtree(pRoot1.leftChild, pRoot2);
            }
            if(!res){
                res = hasSubtree(pRoot1.rightChild, pRoot2);
            }
        }

        return res;
    }

    private static boolean doesTree1HasTree2(BinaryTreeNode pRoot1, BinaryTreeNode pRoot2) {
        if(pRoot2 == null) return true;

        if(pRoot1 == null) return false;

        if(Double.compare(pRoot1.value, pRoot2.value) != 0)
            return false;

        return doesTree1HasTree2(pRoot1.leftChild, pRoot2.leftChild)
                && doesTree1HasTree2(pRoot1.rightChild, pRoot2.rightChild);
    }

    public static void main(String[] args) {
        BinaryTreeNode root1 = new BinaryTreeNode(8 , new BinaryTreeNode(8, new BinaryTreeNode(9, null, null), new BinaryTreeNode(2, new BinaryTreeNode(4, null, null), new BinaryTreeNode(7, null, null))),
                new BinaryTreeNode(7, null, null));
        BinaryTreeNode root2 = new BinaryTreeNode(8, new BinaryTreeNode(9, null, null), new BinaryTreeNode(3, null, null));
        System.out.println(hasSubtree(root1, root2));
    }
}
