package com.learn;

public class Offer19 {
     static boolean match(String str, String pattern){
        if(str == null || pattern == null)
            return false;

        return matchCore(str, pattern, 0, 0);
    }

    static boolean matchCore(String str, String pattern, int indexOfStr, int indexOfPattern) {
        if(str.length() == indexOfStr && pattern.length() == indexOfPattern)
            return true;

        if(str.length() > indexOfStr && pattern.length() == indexOfPattern)
            return false;

        if (indexOfPattern + 1 < pattern.length() && pattern.charAt(indexOfPattern + 1) == '*'){
            //第二位是 *
            if(indexOfStr < str.length() && (pattern.charAt(indexOfPattern) == str.charAt(indexOfStr) || pattern.charAt(indexOfPattern) == '.')){
                //第一位相等或者模式串第一位等于 .
                return     matchCore(str, pattern, indexOfStr + 1, indexOfPattern)  //*号没用
                        || matchCore(str, pattern, indexOfStr + 1, indexOfPattern + 2) // *号只能匹配一位
                        || matchCore(str, pattern, indexOfStr , indexOfPattern + 2);  // * 号能匹配多位

            } else {
                //第一位不等
                return matchCore(str, pattern, indexOfStr, indexOfPattern + 2);
            }
        }

        if(indexOfStr < str.length() &&  indexOfPattern < pattern.length()
                && (str.charAt(indexOfStr) == pattern.charAt(indexOfPattern) || pattern.charAt(indexOfPattern) == '.')){
            return matchCore(str, pattern, indexOfStr + 1, indexOfPattern + 1);
        }
        return false;
    }

    public static void main(String[] args) {
        System.out.println(match("aaa", "a.*aa"));
    }

}
