package com.learn;

import java.util.Arrays;

public class Offer38 {
    static void printString(String s){
        if (s == null) return;
        boolean[] st = new boolean[s.length()];
        Arrays.fill(st, false);
        char[] path = new char[s.length()];
        dfs_2(s, path, 0, st);
    }

    static void dfs_1(String s, char[] path, int index, boolean[] st){
        if(index == s.length()){
            for (char c : path) {
                System.out.print(c);
            }
            System.out.println();
        }

        for (int i = 0; i < s.length(); i++) {
            if(!st[i]){
                path[index] = s.charAt(i);
                st[i] = true;
                dfs_1(s, path, index + 1, st);
                st[i] = false;
            }
        }
    }

    static void dfs_2(String s, char[] path, int index, boolean[] st){
        if(index == s.length()){
            for(int i = 0; i < s.length(); i ++){
                if(st[i]){
                    System.out.print(path[i]);
                }
            }
            System.out.println();
            return;
        }

        st[index] = true;
        path[index] = s.charAt(index);
        dfs_2(s, path, index + 1, st);
        st[index] = false;

        st[index] = false;
        dfs_2(s, path, index + 1, st);
        st[index] = false;
    }

    public static void main(String[] args) {
        printString("abc");
    }
}
