package com.learn;

import java.util.ArrayList;
import java.util.List;

public class Offer34 {

    static List<List<BinaryTreeNode>> allPath = new ArrayList<>();

    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static void findPath(BinaryTreeNode root, int num, int s, List<BinaryTreeNode> path){
        if (root == null) return;

        //当前节点是叶节点
        if(root.lChild == null && root.rChild == null){
            if (s == num){
                List<BinaryTreeNode> realPath = new ArrayList<>(path);
                allPath.add(realPath);
            }
        }

        if (root.lChild != null){
            //有左孩子
            path.add(root.lChild);
            findPath(root.lChild, num, s + root.lChild.value, path);
            path.remove(path.size() - 1);
        }

        if(root.rChild != null){
            //有右孩子
            path.add(root.rChild);
            findPath(root.rChild, num, s + root.rChild.value, path);
            path.remove(path.size() - 1);
        }
    }

    public static void main(String[] args) {
        BinaryTreeNode root = new BinaryTreeNode(10,
                new BinaryTreeNode(5, new BinaryTreeNode(4, null, null), new BinaryTreeNode(7, null, null)),
                new BinaryTreeNode(12, null, null));
        List<BinaryTreeNode> path = new ArrayList<>();
        path.add(root);
        findPath(root, 22, root.value, path);
        allPath.forEach((l) -> {
            l.forEach((e) -> {
                System.out.print(e.value + " ");
            });
            System.out.println();
        });
    }
}
