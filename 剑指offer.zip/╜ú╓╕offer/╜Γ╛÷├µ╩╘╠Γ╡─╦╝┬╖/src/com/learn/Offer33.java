package com.learn;

public class Offer33 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;
    }

    static boolean verifySequenceOfBST(int[] seq, int start, int end){
        if(seq == null || end < 0) return false;

        int root = seq[end];  //根节点的权值

        int i = start;
        for(; i < end; i++){
            if (seq[i] > root) {
                break;
            }
        }

        int j = i;
        for(; j < end; j ++){
            if (seq[j] < root){
                return false;
            }
        }

        boolean left = true;
        if(i > start)
            left = verifySequenceOfBST(seq, start, i - 1);

        boolean right = true;
        if(i < end)
            right = verifySequenceOfBST(seq, i, j - 1);

        return left && right;

    }

    public static void main(String[] args) {
        System.out.println(verifySequenceOfBST(new int[]{5, 7, 6, 9, 11, 10, 8}, 0, 6));
    }
}
