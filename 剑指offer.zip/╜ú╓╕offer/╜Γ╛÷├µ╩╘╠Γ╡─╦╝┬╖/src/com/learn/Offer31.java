package com.learn;

import java.util.Stack;

public class Offer31 {
    static Stack<Integer> mStack = new Stack<>();

    static boolean isPopOrder(int[] pushSeq, int[] popSeq, int length){
        if (popSeq == null || pushSeq == null || length <= 0) return false;

        int j = 0;  //插入序列指针
        int i = 0;
        while (i < length) {
            while (mStack.size() == 0 || mStack.peek() != popSeq[i]){
                if (j >= length) return false;
                mStack.push(pushSeq[j]);
                j ++;
            }
            if (popSeq[i] == mStack.peek()) {
                mStack.pop();
                i ++;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        int[] pop = {4,5,3,2,1};
        int[] push = {1,2,3,4,5};
        System.out.println(isPopOrder(push, pop, pop.length));
    }
}
