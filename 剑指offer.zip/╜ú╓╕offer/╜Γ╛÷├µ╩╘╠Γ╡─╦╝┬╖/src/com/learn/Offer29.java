package com.learn;

import java.util.concurrent.atomic.AtomicInteger;

public class Offer29 {

    static void printMatrix(int[][] matrix, int rows, int cols){
        if (matrix == null || rows <= 0 || cols <= 0) return;

        int start = 0;
        while (rows > start * 2 && cols > start * 2){
            printMatrixInCircle(matrix, rows, cols, start);
            start ++;
        }
    }

    private static void printMatrixInCircle(int[][] matrix, int rows, int cols, int start) {
        int endX = cols - 1 - start;
        int endY = rows - 1 - start;

        //打印 top
        for (int i = start; i <= endX; i++) {
            int number = matrix[start][i];
            System.out.print(number + " ");
        }

        //打印 right
        if(start < endY){
            for (int i = start + 1; i <= endY; i++) {
                int number = matrix[i][endX];
                System.out.print(number + " ");
            }
        }

        //打印 bottom
        if(start < endX && start < endY){
            for (int i = endX - 1; i >= start; i--) {
                int number = matrix[endY][i];
                System.out.print(number + " ");
            }
        }

        //打印 left
        if(start < endX && start < endY - 1){
            for (int i = endY - 1; i >= start + 1; i--) {
                int number = matrix[i][start];
                System.out.print(number + " ");
            }
        }
    }

    public static void main(String[] args) {
        int[][] matrix = new int[][]{
                {1, 2,  3,  4},
                {5, 6,  7,  8},
                {9, 10, 11, 12},
                {13,14, 15, 16}
        };
        printMatrix(matrix, 4, 4);
    }

}
