package com.learn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Offer32 {

    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    /**
     * 题目一
     */
    static void bfsPrintBinaryTree(BinaryTreeNode root){
        if (root == null) return;

        Queue<BinaryTreeNode> q = new ConcurrentLinkedQueue<>();
        q.add(root);
        System.out.print(root.value + " ");
        while (q.size() != 0){
            BinaryTreeNode t = q.poll();
            if (t.lChild != null){
                q.add(t.lChild);
                System.out.print(t.lChild.value + " ");
            }
            if (t.rChild != null){
                q.add(t.rChild);
                System.out.print(t.rChild.value + " ");
            }
        }
    }

    /**
     * 题目二
     */
    static void printBinaryTreeByLevel(BinaryTreeNode root){
        if(root == null) return;

        Queue<BinaryTreeNode> q = new ConcurrentLinkedQueue<>();
        q.add(root);
        int nextLevel = 0;
        int toBePrinted = 1;
        while (q.size() != 0){
            BinaryTreeNode t = q.poll();
            toBePrinted--;
            System.out.print(t.value + " ");

            if (t.lChild != null){
                q.add(t.lChild);
                nextLevel ++;
            }
            if (t.rChild != null){
                q.add(t.rChild);
                nextLevel ++;
            }

            if (toBePrinted == 0){
                System.out.println();
                toBePrinted = nextLevel;
                nextLevel = 0;
            }
        }
    }

    /**
     * 题目三
     */
    static void printBinaryTreeByZ(BinaryTreeNode root){
        if(root == null) return;

        Queue<BinaryTreeNode> q = new ConcurrentLinkedQueue<>();
        q.add(root);
        int nextLevel = 0;
        int toBePrinted = 1;
        boolean isEven = true;
        ArrayList<BinaryTreeNode> list = new ArrayList<>();
        while (q.size() != 0){
            BinaryTreeNode t = q.poll();
            toBePrinted--;
            list.add(t);

            if (t.lChild != null){
                q.add(t.lChild);
                nextLevel ++;
            }
            if (t.rChild != null){
                q.add(t.rChild);
                nextLevel ++;
            }

            if (toBePrinted == 0){
                if (isEven) {
                    list.forEach((e) -> {
                        System.out.print(e.value + " ");
                    });
                }
                else {
                    for (int i = list.size() - 1; i >= 0 ; i --){
                        System.out.print(list.get(i).value + " ");
                    }
                }
                isEven = !isEven;
                System.out.println();
                list.clear();
                toBePrinted = nextLevel;
                nextLevel = 0;
            }
        }
    }

    public static void main(String[] args) {
        BinaryTreeNode root = new BinaryTreeNode();
        root.value = 1;
        root.lChild = new BinaryTreeNode(2,
                new BinaryTreeNode(4, new BinaryTreeNode(8 , null, null), new BinaryTreeNode(9, null, null)),
                new BinaryTreeNode(5, new BinaryTreeNode(10, null, null), new BinaryTreeNode(11, null, null)));
        root.rChild = new BinaryTreeNode(3,
                new BinaryTreeNode(6, new BinaryTreeNode(12, null, null), new BinaryTreeNode(13, null, null)),
                new BinaryTreeNode(7, new BinaryTreeNode(14, null, null), new BinaryTreeNode(15, null, null)));
        printBinaryTreeByZ(root);
    }
}
