package com.learn;

import java.util.Stack;

public class Offer30 {
    Stack<Integer> mData = new Stack<>();
    Stack<Integer> mMin = new Stack<>();

    void push(Integer data){
        mData.push(data);

        if(mMin.size() == 0){
            mMin.push(data);
        } else {
            int min = mMin.peek();
            if(data > min){
                mMin.push(min);
            } else {
                mMin.push(data);
            }
        }
    }

    void pop(){
        mMin.pop();
        mData.pop();
    }

    Integer getMin(){
        return mMin.pop();
    }

    public static void main(String[] args) {
        Offer30 mStack = new Offer30();
        mStack.push(3);
        mStack.push(4);
        mStack.push(2);
        mStack.push(1);
        mStack.pop();
        mStack.pop();
        mStack.push(0);
    }
}
