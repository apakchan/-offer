package com.learn;

public class Offer35 {
    static class ComplexListNode{
        int value;
        ComplexListNode pNext;
        ComplexListNode pSibling;
    }

    public ComplexListNode clone(ComplexListNode pHead){
        cloneNodes(pHead);
        connectSiblingNodes(pHead);
        return reconnectNodes(pHead);
    }

    void cloneNodes(ComplexListNode pHead){
        ComplexListNode pNode = pHead;
        while (pNode != null){
            ComplexListNode pCloned = new ComplexListNode();
            pCloned.value = pNode.value;
            pCloned.pNext = pNode.pNext;
            pCloned.pSibling = null;

            pNode.pNext = pCloned;

            pNode = pCloned.pNext;
        }
    }
    void connectSiblingNodes(ComplexListNode pHead){
        ComplexListNode pNode = pHead;
        while (pNode != null){
            //克隆节点
            ComplexListNode pCloned = pNode.pNext;
            if (pNode.pSibling != null){
                pCloned.pSibling = pNode.pSibling.pNext;
            }
            pNode = pCloned.pNext;
        }
    }

    ComplexListNode reconnectNodes(ComplexListNode pHead){
        ComplexListNode pNode = pHead;
        ComplexListNode pClonedHead = null;
        ComplexListNode pClonedNode = null;

        if (pNode != null){
            pClonedHead = pClonedNode = pNode.pNext;
            pNode.pNext = pClonedNode.pNext;
            pNode = pNode.pNext;
        }

        while (pNode != null){
            pClonedNode.pNext = pNode.pNext;
            pClonedNode = pClonedNode.pNext;
            pNode.pNext = pClonedNode.pNext;
            pNode = pNode.pNext;
        }

        return pClonedHead;
    }

}
