package com.learn;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Offer27 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode leftChild;
        BinaryTreeNode rightChild;

        public BinaryTreeNode(int value, BinaryTreeNode leftChild, BinaryTreeNode rightChild) {
            this.value = value;
            this.leftChild = leftChild;
            this.rightChild = rightChild;
        }

        public BinaryTreeNode() {
        }
    }

    static void mirrorBinaryTree(BinaryTreeNode root){
        if(root == null) return;

        if(root.leftChild == null && root.rightChild == null) return;  //是叶节点

        //交换操作
        BinaryTreeNode temp = root.leftChild;
        root.leftChild = root.rightChild;
        root.rightChild = temp;

        if(root.leftChild != null) mirrorBinaryTree(root.leftChild);  //递归处理左子树
        if(root.rightChild != null) mirrorBinaryTree(root.rightChild);  //递归处理右子树
    }

    static void bfsPrintTree(BinaryTreeNode root){
        Queue<BinaryTreeNode> q = new ConcurrentLinkedQueue<>();
        q.add(root);
        System.out.print(root.value + " ");
        while (q.size() != 0){
            BinaryTreeNode t = q.poll();

            if(t.leftChild != null) {
                q.add(t.leftChild);
                System.out.print(t.leftChild.value + " ");
            }
            if(t.rightChild != null) {
                q.add(t.rightChild);
                System.out.print(t.rightChild.value + " ");
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        BinaryTreeNode root = new BinaryTreeNode(8, null, null);
        root.leftChild = new BinaryTreeNode(6 ,
                new BinaryTreeNode(5, null, null),
                new BinaryTreeNode(7, null, null));
        root.rightChild = new BinaryTreeNode(10,
                new BinaryTreeNode(9, null, null),
                new BinaryTreeNode(11, null, null));
        bfsPrintTree(root);
        mirrorBinaryTree(root);
        bfsPrintTree(root);
    }

}
