package com.learn;

public class Offer36 {
    static class BinaryTreeNode{
        int value;

        public BinaryTreeNode() {
        }

        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    static BinaryTreeNode pLastNodeInList = null;

    static BinaryTreeNode convert(BinaryTreeNode root){
        convertNode(root);

        BinaryTreeNode pHeadOfList = pLastNodeInList;
        while (pHeadOfList != null && pHeadOfList.lChild != null){
            pHeadOfList = pHeadOfList.lChild;
        }

        return pHeadOfList;
    }

    static void convertNode(BinaryTreeNode pNode) {
        if (pNode == null) return;

        BinaryTreeNode pCurrent = pNode;

        if (pCurrent.lChild != null){
            convertNode(pCurrent.lChild);
        }

        pCurrent.lChild = pLastNodeInList;
        if(pLastNodeInList != null){
            pLastNodeInList.rChild = pCurrent;
        }

        pLastNodeInList = pCurrent;

        if(pCurrent.rChild != null){
            convertNode(pCurrent.rChild);
        }
    }

    public static void main(String[] args) {
        BinaryTreeNode root = new BinaryTreeNode(10, null, null);
        BinaryTreeNode left = new BinaryTreeNode(6,
                new BinaryTreeNode(4, null, null),
                new BinaryTreeNode(8, null, null));
        BinaryTreeNode right = new BinaryTreeNode(14,
                new BinaryTreeNode(12, null, null),
                new BinaryTreeNode(16, null, null));
        root.lChild = left;
        root.rChild = right;
        BinaryTreeNode head = convert(root);

        while (head != null) {

            System.out.println(head.value);
            head = head.rChild;
        }
    }

}
