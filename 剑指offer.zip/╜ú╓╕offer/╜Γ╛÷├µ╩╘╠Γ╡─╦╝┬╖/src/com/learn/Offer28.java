package com.learn;

public class Offer28 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode(int value, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.lChild = lChild;
            this.rChild = rChild;
        }

        public BinaryTreeNode() {
        }
    }

    static boolean isMirror(BinaryTreeNode root){
        return isMirror(root, root);
    }

    private static boolean isMirror(BinaryTreeNode root1, BinaryTreeNode root2) {
        if(root1 == null && root2 == null) return true;  //如果都是空的话返回true

        if(root1 == null || root2 == null) return false;  //有一个是null另一个不是null 返回false
        
        if(root1.value != root2.value) return false;
        
        return isMirror(root1.lChild, root2.rChild) && isMirror(root1.rChild, root2.lChild);  //递归判断前序左镜像前序右和前序右镜像前序左
    }

    public static void main(String[] args) {
        BinaryTreeNode root = new BinaryTreeNode(7, null, null);
        root.lChild = new BinaryTreeNode(7,
                new BinaryTreeNode(7, null, null),
                new BinaryTreeNode(7, null, null));
        root.rChild = new BinaryTreeNode(7,
                new BinaryTreeNode(7, null, null),
                null);
        System.out.println(isMirror(root));
    }

}
