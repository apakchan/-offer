package com.learn;

public class Offer8 {
    static class BinaryTreeNode{
        int value;
        BinaryTreeNode parent;
        BinaryTreeNode lChild;
        BinaryTreeNode rChild;

        public BinaryTreeNode() {
        }

        public BinaryTreeNode(int value, BinaryTreeNode parent, BinaryTreeNode lChild, BinaryTreeNode rChild) {
            this.value = value;
            this.parent = parent;
            this.lChild = lChild;
            this.rChild = rChild;
        }
    }

    /**
     * 如果这个节点有右子树，则返回右子树的中序遍历的第一个节点
     * 如果这个节点没有右子树，且是其父节点的左子树，则其下一个节点是其父节点
     * 如果这个节点没有右子树，且是其父节点的右子树，则我们沿着指向父节点的指针一直向上，直到找到一个是它父节点的左子节点的节点，则这个节点的父节点就是我们要找的下一个节点
     * @param node
     * @return
     */

    static BinaryTreeNode getNext(BinaryTreeNode node){
        if(node == null) return null;

        BinaryTreeNode pNext = null;

        if(node.rChild != null){
            //如果这个节点有右子树
            pNext = node.rChild;
            while (pNext.lChild != null){
                pNext = pNext.lChild;
            }
        } else if(node.parent != null){
            BinaryTreeNode parent = node.parent;
            if(parent.lChild == node){
                //如果这个节点是它父节点的左节点
                pNext = parent;
            } else {  //这个节点是它父节点的右节点
                BinaryTreeNode pCurrent = node;
                BinaryTreeNode pParent = node.parent;
                while(pParent != null && pParent.lChild != pCurrent){
                    pParent = pParent.parent;
                    pCurrent = pCurrent.parent;
                }
                pNext = pParent;
            }
        }
        return pNext;
    }

    public static void main(String[] args) {

    }

}
