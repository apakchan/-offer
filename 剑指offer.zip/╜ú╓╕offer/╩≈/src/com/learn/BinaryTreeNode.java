package com.learn;

public class BinaryTreeNode {
    int value;
    BinaryTreeNode lChild;
    BinaryTreeNode rChild;
}
