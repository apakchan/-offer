package com.learn;


import java.util.Queue;

public class Offer7 {

    static BinaryTreeNode build(int il, int ir, int pl, int pr, int[] pre, int[] in){
        BinaryTreeNode root = new BinaryTreeNode();
        root.value = pre[pl];
        int k = 0;
        for (int i= 0; i < pre.length; i ++) {
            if(in[i] == root.value){
                k = i;
                break;
            }
        }

        if(il < k) root.lChild = build(il, k - 1, pl + 1, pl + 1 + k - 1 - il, pre, in);  //重建左子树
        if(ir > k) root.rChild = build(k + 1, ir, pl + 1 + k - 1 - il + 1, pr, pre, in);  //重建右子树

        return root;
    }

    static BinaryTreeNode construct(int[] pre, int[] in, int length){
        if(pre == null || in == null || length <= 0) return null;

        BinaryTreeNode root = build(0, length - 1, 0, length - 1, pre, in);

        return root;
    }

    static void printTreeNodeInLevel(BinaryTreeNode root, int length){
        BinaryTreeNode[] q = new BinaryTreeNode[length];
        int hh = 0, tt = 0;
        q[0] = root;
        while (hh <= tt){
            BinaryTreeNode t = q[hh ++];
            if (t.lChild != null) q[++ tt] = t.lChild;
            if (t.rChild != null) q[++ tt] = t.rChild;
        }

        for (BinaryTreeNode binaryTreeNode : q) {
            System.out.print(binaryTreeNode.value + " ");
        }
    }

    public static void main(String[] args) {
        int[] pre = new int[]{1, 2, 4, 7, 3, 5, 6, 8};
        int[] in = new int[]{4, 7, 2, 1, 5, 3, 8, 6};
        BinaryTreeNode root = construct(pre, in, pre.length == in.length ? pre.length : -1);
        printTreeNodeInLevel(root, pre.length == in.length ? pre.length : -1);
    }
}
