package com.learn;

import java.math.BigInteger;

public class Offer10 {
    static BigInteger fibonacci_r(int n){

        if(n == 1) return BigInteger.valueOf(1);

        if(n <= 0) return BigInteger.valueOf(0);

        return fibonacci_r(n - 1).add(fibonacci_r(n - 2));
    }

    static BigInteger fibonacci_i(int n){
        int[] result = new int[]{0, 1};
        if(n < 2) return BigInteger.valueOf(result[n]);

        BigInteger fibNMinusOne = BigInteger.ONE;
        BigInteger fibNMinusTwo = BigInteger.ZERO;
        BigInteger fibN = BigInteger.ZERO;

        for(int i = 2; i <= n; i ++){
            fibN = fibNMinusOne.add(fibNMinusTwo);

            fibNMinusTwo = fibNMinusOne;
            fibNMinusOne = fibN;
        }

        return fibN;
    }

    public static void main(String[] args) {
        System.out.println(fibonacci_i(10));
    }

}
