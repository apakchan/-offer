package com.learn;

public class Offer5 {

    private static String change(String s, int len) {
        if(s == null || len <= 0) return null;

        int cnt = 0;
        for(int i = 0; i < len; i ++) {
            if(s.charAt(i) == ' '){
                cnt ++;
            }
        }

        StringBuilder sb = new StringBuilder(len + cnt * 2);

        int lastIndex = 0;
        for(int i = 0; i < len; i ++) {
            if(s.charAt(i) == ' ') {
                sb.append(s, lastIndex, i).append("%20");
                lastIndex = i + 1;
            }
        }
        sb.append(s, lastIndex, len);

        return sb.toString();
    }


    public static void main(String[] args) {
        String s = " We are happy ";
        s = change(s, s.length());
        System.out.println(s);
    }
}
